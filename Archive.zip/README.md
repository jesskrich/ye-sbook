Replaces color background Facebook status updates with Kanye West quotes.
