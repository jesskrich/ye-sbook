#Load content without page refresh
#toggle icons
#enable/disable
